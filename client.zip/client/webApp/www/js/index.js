

// Server base domain url 
// const domainUrl = "http://localhost:3000";  // if local test, please use this 
 const domainUrl = "https://express-server-83p1.onrender.com" 


var authenticated = false;

$(document).ready(function () {
	
	// Common function to check if all fields are empty
	function areFieldsEmpty(ids) {
		return ids.every(id => $.trim($(id).val()) === "");
	}
	
	function getFortnightRange(date) {
		const year = date.getFullYear();
		const month = date.getMonth(); 

		let firstMonday = new Date(year, month, 1);
		while (firstMonday.getDay() !== 1) { 
			firstMonday.setDate(firstMonday.getDate() + 1);
		}

		const secondMonday = new Date(firstMonday);
		secondMonday.setDate(firstMonday.getDate() + 7);

		const thirdMonday = new Date(firstMonday);
		thirdMonday.setDate(firstMonday.getDate() + 14);

		let start, end;

		if (date >= firstMonday && date < thirdMonday) {
			start = new Date(firstMonday);
			end = new Date(thirdMonday);
			end.setDate(thirdMonday.getDate() - 1); 
			end.setHours(23, 59, 59, 999);
		} else {
			start = new Date(thirdMonday);
			end = new Date(year, month + 1, 0, 23, 59, 59, 999);
		}

		return { start, end };
	}


	function getStartOfWeek(date) {
		const day = date.getDay(); 
		const diff = (day === 0 ? -6 : 1) - day; 
		const start = new Date(date);
		start.setDate(date.getDate() + diff);
		start.setHours(0, 0, 0, 0);
		return start;
	}

	function getEndOfWeek(date) {
		const start = getStartOfWeek(date);
		const end = new Date(start);
		end.setDate(start.getDate() + 6);
		end.setHours(23, 59, 59, 999);
		return end;
	}

	// LOGIN FORM
	$("#loginForm").on("submit", function (e) {
		e.preventDefault();

		const email = $("#loginEmail").val();
		const password = $("#loginPassword").val();
		if (areFieldsEmpty(["#loginEmail", "#loginPassword"])) {
			$("#loginAlert").text("Please enter the details").show();
			return;
		}

		const valid = $("#loginForm").validate({
		  rules: {
			loginEmail: {
			  required: true,
			  email: true
			},
			loginPassword: {
			  required: true,
			  minlength: 6
			}
		  },
		  messages: {
			loginEmail: {
			  required: "Please enter your email",
			  email: "Invalid email format"
			},
			loginPassword: {
			  required: "Password is required",
			  minlength: "Password must be at least 6 characters"
			}
		  },
		  errorPlacement: function (error) {
			$("#loginAlert").text(error.text()).show();
		  }
		}).form();

		if (valid) {
			const loginData = {
				email: $("#loginEmail").val(),
				password: $("#loginPassword").val()
			};
			  
			$("#loginAlert").hide();
		  
			$.post(domainUrl + "/verifyUserCredential", loginData, function (data, status) {
				if (data != null) {
					authenticated = true;
					localStorage.setItem("userInfo", JSON.stringify(data));
					$("body").pagecontainer("change", "#homePage");
				} else {
					$("#loginAlert").text("Login failed!").show();
				}
				$("#loginForm").trigger("reset");
			})
			.fail(function (xhr, status, error) {
				console.error("Login request failed:", error);
				$("#loginAlert").text("Server unreachable.").show();
			});
		}

	});

	// SIGNUP FORM
	$("#signupForm").on("submit", function (e) {
		e.preventDefault();

		if (areFieldsEmpty(["#registerName", "#registerEmail", "#registerPassword", "#registerPasswordConfirm"])) {
		  $("#registerAlert").text("Please enter the details").show();
		  return;
		}

		const valid = $("#signupForm").validate({
		  rules: {
			fullName: {
			  required: true
			},
			signupEmail: {
			  required: true,
			  email: true
			},
			password: {
			  required: true,
			  minlength: 6
			},
			confirmPassword: {
			  required: true,
			  equalTo: "#registerPassword"
			}
		  },
		  messages: {
			fullName: {
			  required: "Full name is required"
			},
			signupEmail: {
			  required: "Email is required",
			  email: "Invalid email format"
			},
			password: {
			  required: "Password is required",
			  minlength: "Password must be atleast 6 characters"
			},
			confirmPassword: {
			  required: "Please confirm your password",
			  equalTo: "Passwords do not match"
			}
		  },
		  errorPlacement: function (error) {
			$("#registerAlert").text(error.text()).show();
		  }
		}).form();

		if (valid) {
			const signupData = {
			  fullName: $("#registerName").val(), 
			  email: $("#registerEmail").val(), 
			  password: $("#registerPassword").val(),
			  allowedHours: 48
			};
			
			$("#registerAlert").hide();
			
			$.get(domainUrl + "/verifyNewUserEmail" + "?email=" + signupData.email,  function(data, status) {				
				if (data != null) {
					$("#registerAlert").text("Email already exists").show();
				} 
				else {
					$.post(domainUrl + "/insertUserData", signupData,  function(data, status) {
						if (Object.keys(data).length > 0) {
							authenticated = true;
							localStorage.setItem("userInfo", JSON.stringify(signupData));	
							$("body").pagecontainer("change", "#homePage");
						} 
						else {
							alert("Sign Up failed");
							$("#registerAlert").text("Sign Up failed").show();
						}
						$("#signUpForm").trigger('reset');	
					}).fail(function (xhr, status, error) {
						console.error("Registration failed:", error);
						$("#registerAlert").text("Server unreachable.").show();
					});
				}
			}).fail(function (xhr, status, error) {
				console.error("Email check failed:", error);
				$("#registerAlert").text("Server unreachable.").show();
			});
		}
	});
	
	// ADD JOB 
	$("#addJobBtn").on("click", function () {
		const jobName = $("#jobNameInput").val().trim();

		const user = JSON.parse(localStorage.getItem("userInfo")).email;
		if (!user) {
			alert("User not logged in");
			return;
		}
	
		if (!jobName) {
			$("#addJobAlert").text("Please enter a job name").show();
			return;
		}
		
		$("#addJobAlert").hide();

		$.get(domainUrl + "/verifyNewJobName", { jobName, userEmail: user },  function(response) {				
			if (response != null) {
				$("#addJobAlert").text("Job already exists").show();
			} 
			else {
				$.post(domainUrl + "/insertJobData", { name: jobName, userEmail: user }, function (data, status) {
					if (data && data.insertedId) {
						$("#jobNameInput").val("");
						$("body").pagecontainer("change", "#homePage");
					} else {
						$("#addJobAlert").text("Failed to add job").show();
					}
				}).fail(function (xhr, status, error) {
					console.error("Add Job error:", error);
					$("#addJobAlert").text("Server error.").show();
				});
			}
		}).fail(function (xhr, status, error) {
			console.error("Email check failed:", error);
			$("#registerAlert").text("Server unreachable.").show();
		});
	});
	
	// RECORD HOURS FORM 
	$("#recordForm").on("submit", function (e) {
		e.preventDefault();

		const date = $("#recordDate").val();
		const clockIn = $("#clockInTime").val();
		const clockOut = $("#clockOutTime").val();
		const alertBox = $("#recordAlert");

		const job = JSON.parse(localStorage.getItem("job"));
		if (!job || !job.name) {
			alert("Job Not Selected");
			return;
		}
		
		alertBox.hide();

		if (!date || !clockIn || !clockOut) {
			alertBox.text("All fields are required.").show();
			return;
		}

		if (clockIn >= clockOut) {
			alertBox.text("Clock Out time must be after Clock In time.").show();
			return;
		}

		const [inHours, inMinutes] = clockIn.split(":").map(Number);
		const [outHours, outMinutes] = clockOut.split(":").map(Number);
		const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes);
		const hoursWorked = (totalMinutes / 60).toFixed(2);

		const user = JSON.parse(localStorage.getItem("userInfo"));
		const hourData = {
			userEmail: user.email,
			jobName: job.name,
			date,
			clockInTime: clockIn,
			clockOutTime: clockOut,
			hoursWorked
		};

		$.post(domainUrl + "/insertHourData", hourData, function (data, status) {
			if (data && data.insertedId) {
				localStorage.setItem("lastRecorded", JSON.stringify({
				  jobName: JSON.parse(localStorage.getItem("job")).name,
				  clockIn: hourData.clockInTime,
				  clockOut: hourData.clockOutTime,
				  hoursWorked: hourData.hoursWorked
				}));
				$("body").pagecontainer("change", "#confirmationPage");
			} else {
				alertBox.text("Failed to record hours.").show();
			}
		}).fail(function (xhr, status, error) {
				alertBox.text("Server unreachable.").show();
		});
	});
	
	$(document).on("pagebeforeshow", "#loginPage", function() {
		localStorage.removeItem("userInfo");
		authenticated = false;
	});
	
	$(document).on("pagebeforeshow", "#registerPage", function() {
		$("#registerName").val("");
		$("#registerEmail").val("");
		$("#registerPassword").val("");
		$("#registerPasswordConfirm").val("");
	});
	
	$(document).on("pagebeforeshow", "#homePage", function () {

		localStorage.removeItem("job");
		const user = JSON.parse(localStorage.getItem("userInfo"));
		if (!user) return;
		selectedJobName = "";
		
		$.get(domainUrl + "/getJobs?userEmail=" + user.email, function (data, status) {
			const jobList = $("#jobList");
			jobList.empty();

			if (data.length === 0) {
			  jobList.append(`<li><p>No jobs found. Please add a job.</p></li>`);
			} else {
			  data.forEach(job => {
				jobList.append(`
				  <li>
					<a href="#recordHoursPage" class="job-item" data-jobname="${job.name}">
					  <h2>${job.name}</h2>
					</a>
				  </li>
				`);
			  });
			}
			jobList.listview("refresh");
			
		}).fail(function (xhr, status, error) {
			$("#jobList").append("<li>Failed to load jobs</li>").listview("refresh");
		});
		

		$.get(domainUrl + "/getHoursForAllJobs", { userEmail: user.email }, (records) => {
			
			const today = new Date();
			const weekStart = getStartOfWeek(today);
			const weekEnd = getEndOfWeek(today);
			const { start: fortnightStart, end: fortnightEnd } = getFortnightRange(today);
			const weekHours = records
			  .filter(r => {
				const d = new Date(r.date);
				return d >= weekStart && d <= weekEnd;
			  })
			  .reduce((sum, r) => sum + parseFloat(r.hoursWorked || 0), 0);
			const fortnightHours = records
			  .filter(r => {
				const d = new Date(r.date);
				return d >= fortnightStart && d <= fortnightEnd;
			  })
			  .reduce((sum, r) => sum + parseFloat(r.hoursWorked || 0), 0);

			document.getElementById('weeklyTotal').textContent = weekHours.toFixed(2);
			document.getElementById('fortnightTotal').textContent = fortnightHours.toFixed(2);
			
			const { start } = getFortnightRange(new Date());
			const remainingHours = user.allowedHours - fortnightHours.toFixed(2);
			const remainingText = remainingHours > 0 
				? `${remainingHours.toFixed(2)} hrs remaining`
				: `Limit exceeded by ${Math.abs(remainingHours).toFixed(2)} hrs`;

			const formattedDate = start.toLocaleDateString("en-AU");

			$("#fortnightStart").text(formattedDate);
			$("#fortnightTimeRemaining").text(remainingText);

		})
		.fail(function (xhr, status, error) {
			$("#weeklyTotal").text("Error");
			$("#fortnightTotal").text("Error");
		});
		
		$("#allowedHoursInput").val(user.allowedHours);
		
	});
	
	$(document).on("click", ".job-item", function () {
		localStorage.setItem("job", JSON.stringify({name: $(this).data("jobname")}));
	});
	
	$(document).on("pagebeforeshow", "#addJobPage", function () {
		$("#jobNameInput").val("");
		$("#addJobAlert").hide();
	});
	
	$(document).on("pagebeforeshow", "#recordHoursPage", function () {
		
		localStorage.removeItem("lastRecorded");
		$("#recordDate").val("");
		$("#clockInTime").val("");
		$("#clockOutTime").val("");
		$("#recordAlert").hide();
		
		const today = new Date().toISOString().split("T")[0];
		$("#recordDate").attr("max", today);
		$("#recordDate").val(today);

		const user = JSON.parse(localStorage.getItem("userInfo"));
		const jobName = JSON.parse(localStorage.getItem("job"));
		if (!user || !jobName) {
			$("#recordAlert").text("Please log in again.").show();
			return;
		}
		
		$("#jobNameLabel").text(jobName.name);

		$.get(domainUrl + "/getHours", { userEmail: user.email, jobName: jobName.name }, function (records) {
			let totalWeekHours = 0;
			const $recordList = $("#recordList");
			const $noRecords = $("#noRecords");

			$recordList.empty();
			const startOfWeek = new Date(getStartOfWeek(new Date()));

			const weekRecords = records.filter(record => {
			  const recordDate = new Date(record.date);
			  return recordDate >= startOfWeek;
			});

			if (records.length === 0) {
				$noRecords.show();
			} else {
				$noRecords.hide();

				records.sort((a, b) => new Date(b.date) - new Date(a.date));
				weekRecords.forEach(record => {
					totalWeekHours += record.hoursWorked;
				});
				
				records.forEach(record => {

					const item = `
					<li style="margin-top: 10px;" class="ui-li-static ui-body-inherit ui-first-child">
						<div style="display: flex; justify-content: space-between; align-items: center;">
						<div>
							<h3 style="margin: 0; font-size: 1.1em;">${record.date}</h3>
							<p style="margin: 4px 0 0 0; font-size: 0.95em;">
							${record.clockInTime} - ${record.clockOutTime} 
							<strong>(${record.hoursWorked} hrs)</strong>
							</p>
						</div>
						<span class="delete-record" 
						data-id="${record._id}" 
						style="font-size: 20px; cursor: pointer;">🗑️</span>
						</div>
					</li>
					`;

					$recordList.append(item);
				});

				$recordList.listview("refresh");
			}

			$("#jobWeekTotal").text(totalWeekHours.toFixed(2));
		});
	});

	$(document).on("pagebeforeshow", "#confirmationPage", function () {
		const data = JSON.parse(localStorage.getItem("lastRecorded"));

		if (data) {
			$("#confJobName").text(data.jobName);
			$("#confClockIn").text(data.clockIn);
			$("#confClockOut").text(data.clockOut);
			$("#confTotalHours").text(data.hoursWorked);
		}
	});

	$(document).on("click", "#deleteRecordBtn", function () {

		const userEmail = JSON.parse(localStorage.getItem("userInfo")).email;
		if (!userEmail) {
			alert("User not logged in");
			return;
		}
		const jobName = JSON.parse(localStorage.getItem("job")).name;
		if (!jobName) {
			alert("Job Not Selected");
			return;
		}

		if (confirm(`Are you sure you want to delete the job "${jobName}"?\nThis will also delete all recorded hours for this job.`)) {
			$.ajax({
			  url: domainUrl + "/deleteJobAndHours",
			  type: "DELETE",
			  contentType: "application/json",
			  data: JSON.stringify({ userEmail, jobName }),
			  success: function () {
				window.location.href = "#homePage";
			  },
			  error: function () {
				
			  }
			});
		}
	});
	
	$(document).on("click", ".delete-record", function () {
		const recordId = $(this).data("id");
		if (confirm("Are you sure you want to delete this hour record?")) {
			$.ajax({
				url: domainUrl + `/deleteHourRecord/${recordId}`,
				type: 'DELETE',
				success: function () {
					alert("Record deleted successfully.");
					$("#recordHoursPage").trigger("pagebeforeshow");
				},
				error: function (err) {
					console.error(err);
					alert("Failed to delete record.");
				}
			});
		}
	});

	$("#saveSettingsBtn").click(function () {
		const email = JSON.parse(localStorage.getItem("userInfo")).email;
		const newHours = parseFloat($("#allowedHoursInput").val());

		if (isNaN(newHours) || newHours <= 0) {
			$("#addConfigAlert").text("Please enter a valid number of hours.").show();
			return;
		}

		$.ajax({
			url: domainUrl + "/updateAllowedHours",
			type: "PUT",
			data: JSON.stringify({ email: email, allowedHours: newHours }),
			contentType: "application/json",
			success: function () {
				$("#settingsAlert label").text("Settings saved successfully.");
				$("#settingsAlert").css("color", "green").fadeIn().delay(3000).fadeOut();
				
				const user = JSON.parse(localStorage.getItem("userInfo"));
				user.allowedHours = newHours;
				localStorage.setItem("userInfo", JSON.stringify(user));
				
				$("body").pagecontainer("change", "#homePage");
			},
			error: function () {
				$("#settingsAlert label").text("Error saving setting.");
				$("#settingsAlert").css("color", "red").fadeIn().delay(3000).fadeOut();
			}
		}); 
	});

});
